// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Function to log out the user
Future<void> logoutUser(BuildContext context) async {
  try {
    // Retrieve the current user's ID. This should be stored or retrieved from your authentication mechanism.
    String userId = 'currentUserId'; // Replace this with the actual user ID

    // Update the user's document in Firestore to remove the session token
    await FirebaseFirestore.instance.collection('users').doc(userId).update({
      'sessionToken': FieldValue.delete(), // This will remove the session token
    });

    // Optionally, navigate to the login screen or show a confirmation message
    // For example:
    Navigator.pushReplacementNamed(
        context, '/login'); // Update the route name as needed

    // Optionally, show a snackbar or toast for confirmation
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Successfully logged out')),
    );
  } catch (e) {
    // Handle any errors that occur during logout
    print('Error logging out: $e');
  }
}
