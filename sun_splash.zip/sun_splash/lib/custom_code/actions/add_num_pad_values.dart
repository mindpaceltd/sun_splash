// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<String> addNumPadValues(
  String char,
  String? inputValue,
) async {
  // Initialize inputValue with '-' if it's null
  inputValue ??= '-';

  // Check if the input starts with '-' and replace it with `char`
  if (inputValue == '-') {
    return char; // Replace '-' with the first character entered
  }

  // Append the `char` to inputValue if the current length is less than 6 characters
  if (inputValue.length < 6) {
    return inputValue + char; // Append new character
  }

  // Return the existing inputValue if it has reached 6 characters
  return inputValue;
}
