// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

Future<void> printRestaurantReceipt(
  String orderNo,
  String tableNo,
  double totalAmount,
  String cashier,
  List<ItemsStruct> items, // List of ItemsStruct objects for items
) async {
  const PdfPageFormat pageFormat = PdfPageFormat.roll80;

  // Create PDF document
  final pdf = pw.Document();

  pdf.addPage(
    pw.Page(
      pageFormat: pageFormat,
      margin: const pw.EdgeInsets.all(8),
      build: (pw.Context context) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          // Restaurant name and details
          pw.Text(
            "SunSplash Jamaican Restaurant & Lounge",
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(
              fontSize: 14,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.Text(
            "38B Buganda Rd, Kampala",
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(fontSize: 10),
          ),
          pw.Text(
            "Phone: 0755 049992",
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(fontSize: 10),
          ),
          pw.SizedBox(height: 8),
          pw.Divider(thickness: 1),

          // Order information
          pw.Text(
            "Order Receipt",
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(
              fontSize: 12,
              fontWeight: pw.FontWeight.bold,
              decoration: pw.TextDecoration.underline,
            ),
          ),
          pw.SizedBox(height: 8),
          _buildRow("Order No:", orderNo),
          _buildRow("Table No:", tableNo),
          _buildRow("Cashier:", cashier),
          pw.SizedBox(height: 8),
          pw.Divider(thickness: 1),

          // Items header
          pw.Text(
            "Items",
            style: pw.TextStyle(
              fontSize: 12,
              fontWeight: pw.FontWeight.bold,
              decoration: pw.TextDecoration.underline,
            ),
          ),
          pw.SizedBox(height: 4),

          // Items list
          pw.Table(
            border: pw.TableBorder.symmetric(inside: pw.BorderSide(width: 0.5)),
            columnWidths: {
              0: const pw.FlexColumnWidth(3),
              1: const pw.FlexColumnWidth(1),
            },
            children: [
              // Table headers
              pw.TableRow(children: [
                pw.Text("Item",
                    style: pw.TextStyle(
                        fontWeight: pw.FontWeight.bold, fontSize: 10)),
                pw.Text("Price",
                    style: pw.TextStyle(
                        fontWeight: pw.FontWeight.bold, fontSize: 10)),
              ]),
              // Table rows for items
              ...items.map(
                (item) => pw.TableRow(children: [
                  pw.Text(item.name ?? "Unknown Item",
                      style: pw.TextStyle(fontSize: 10)),
                  pw.Text(item.price?.toStringAsFixed(2) ?? "0.00",
                      style: pw.TextStyle(fontSize: 10)),
                ]),
              ),
            ],
          ),
          pw.SizedBox(height: 8),

          // Total
          pw.Divider(thickness: 1),
          _buildRow(
            "Total Amount:",
            "UGX ${totalAmount.toStringAsFixed(2)}",
            bold: true,
            size: 12,
          ),
          pw.Divider(thickness: 1),
          pw.SizedBox(height: 8),

          // Footer
          pw.Text(
            "Thank you for dining with us!",
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            "We hope to see you again soon.",
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(fontSize: 10),
          ),
        ],
      ),
    ),
  );

  await Printing.layoutPdf(onLayout: (PdfPageFormat format) async {
    final Uint8List pdfBytes = await pdf.save();
    return pdfBytes;
  });
}

// Utility to build rows with optional bold text
pw.Widget _buildRow(String label, String value,
    {bool bold = false, double size = 10}) {
  return pw.Row(
    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
    children: [
      pw.Text(
        label,
        style: pw.TextStyle(
            fontSize: size,
            fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal),
      ),
      pw.Text(
        value,
        style: pw.TextStyle(
            fontSize: size,
            fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal),
      ),
    ],
  );
}
