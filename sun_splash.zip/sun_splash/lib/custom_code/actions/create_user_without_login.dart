// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

Future<String?> createUserWithoutLogin(
  String email,
  String password,
  String displayName,
  String photoUrl,
  String role,
  String phoneNumber,
) async {
  String returnUid = "";

  // Initialize secondary Firebase app
  FirebaseApp app = await Firebase.initializeApp(
    name: 'Secondary',
    options: Firebase.app().options,
  );

  try {
    // Create user with specified email and password
    UserCredential userCredential = await FirebaseAuth.instanceFor(app: app)
        .createUserWithEmailAndPassword(email: email, password: password);

    User user = userCredential.user!;

    // Update additional user properties
    await user.updateDisplayName(displayName);
    await user.updatePhotoURL(photoUrl);

    // Store additional user data in Firestore
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    await firestore.collection('users').doc(user.uid).set({
      'display_name': displayName,
      'photo_url': photoUrl,
      'role': role,
      'phone_number': phoneNumber,
      'email': email,
      'created_time': FieldValue.serverTimestamp(),
    });

    returnUid = user.uid;
  } on FirebaseAuthException catch (e) {
    print('Firebase Auth Error: ${e.message}');
  } catch (e) {
    print('General Error: $e');
  } finally {
    await app.delete();
  }

  return returnUid;
}
