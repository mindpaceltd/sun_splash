// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

Future updateQty(List<DocumentReference>? cart) async {
  try {
    for (var cartRef in cart!) {
      // Get the Cart document data
      DocumentSnapshot cartSnapshot = await cartRef.get();
      Map<String, dynamic> cartData =
          cartSnapshot.data() as Map<String, dynamic>;

      // Get the list of items from the cart
      List<dynamic> items = cartData['items'] ?? [];

      // Process each item in the cart
      for (var item in items) {
        DocumentReference menuItemRef =
            item['menuItemRef']; // Menu Item Reference
        int qty = item['qty'] ?? 0; // Quantity

        if (qty > 0) {
          // Get the Menu_Item document
          DocumentSnapshot menuItemSnapshot = await menuItemRef.get();
          Map<String, dynamic> menuItemData =
              menuItemSnapshot.data() as Map<String, dynamic>;

          // Check and update the quantity
          int currentQty = menuItemData['qty'] ?? 0;
          if (currentQty >= qty) {
            int updatedQty = currentQty - qty;
            await menuItemRef.update({'qty': updatedQty});
          } else {
            throw Exception('Not enough stock for ${menuItemData['name']}');
          }
        }
      }
    }
  } catch (e) {
    print('Error updating menu item quantities: $e');
    rethrow;
  }
}
