// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart'; // Import for Timestamp

Future shiftAction(
  BuildContext context,
  DocumentReference? shiftRef,
) async {
  if (shiftRef == null) {
    print("Shift reference is null.");
    return;
  }

  try {
    // Fetch the shift document using the provided shiftRef
    final shiftSnapshot = await shiftRef.get();
    if (!shiftSnapshot.exists) {
      print("Shift document not found.");
      return;
    }

    // Cast shiftData to Map<String, dynamic>
    final shiftData = shiftSnapshot.data() as Map<String, dynamic>;

    // Assuming 'salesSummary' exists in the shift data and calculating total sales
    final salesSummary = (shiftData['salesSummary'] as List<dynamic>?) ?? [];
    double totalSales = 0.0;

    for (var sale in salesSummary) {
      // Ensure each sale is a Map<String, dynamic>
      if (sale is Map<String, dynamic>) {
        double price = (sale['price'] ?? 0.0).toDouble();
        int quantity = (sale['quantity'] ?? 0).toInt();
        totalSales += price * quantity;
      }
    }

    // Extracting shift details (start time, end time, etc.)
    DateTime startTime = (shiftData['startTime'] as Timestamp).toDate();
    DateTime endTime = (shiftData['endTime'] as Timestamp).toDate();

    // Constructing the shift summary
    final shiftSummary = '''
      Shift Summary:
      ---------------------
      Shift Start: ${startTime.toString()}
      Shift End: ${endTime.toString()}
      
      Sales Summary:
      ---------------------
      Total Items Sold: ${salesSummary.length}
      Total Sales: \$${totalSales.toStringAsFixed(2)}
      ---------------------
      ''';

    // Printing the shift summary to the console
    print(shiftSummary);

    // Optional: Implement printer logic if needed
    // PrinterLogic.print(shiftSummary); // Example printer logic
  } catch (e) {
    print("Error fetching or processing shift data: $e");
  }
}
