import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

String? checkCurrentTime() {
  // function to check the current time if its morning returns good morning, if noon good after noon likewise for evening
  var now = DateTime.now();
  var currentTime = now.hour;

  if (currentTime >= 5 && currentTime < 12) {
    return 'Good Morning';
  } else if (currentTime >= 12 && currentTime < 17) {
    return 'Good Afternoon';
  } else if (currentTime >= 17 && currentTime < 20) {
    return 'Good Evening';
  } else {
    return 'Good Night';
  }
}

String? accessSixthChar(String? items) {
  // function to access the second char from the string and return it
  if (items == null || items.length < 6) {
    return null;
  }

  return items[5];
}

String? accessFifthChar(String? items) {
  // function to access the second char from the string and return it
  if (items == null || items.length < 5) {
    return null;
  }

  return items[4];
}

String? accessThirdChar(String? items) {
  // function to access the second char from the string and return it
  if (items == null || items.length < 3) {
    return null;
  }

  return items[2];
}

String? accessFourthChar(String? items) {
  // function to access the second char from the string and return it
  if (items == null || items.length < 4) {
    return null;
  }

  return items[3];
}

List<MenuItemsRecord> itemList(
  List<MenuItemsRecord> list,
  List<MenuItemsRecord> searchlist,
) {
  return searchlist.length > 0 ? searchlist : list;
}

DocumentReference? queryCat(String catRef) {
  // i need to query the Categories document for the document reference matching the argument
  return FirebaseFirestore.instance.collection('Categories').doc(catRef);
}

double decreamentCartTotal(
  double price,
  double totalValue,
) {
  return totalValue - price;
}

double increamentCartTotal(
  double price,
  double totalValue,
) {
  return totalValue + price;
}

double calculatePrice(
  double price,
  int qty,
) {
  return qty * price;
}

double totalSales(List<double> totalSale) {
  // i need the summation of the list of totalSale Argument return the sum
  return totalSale.reduce((value, element) => value + element);
}

String mergeChars(List<String> chars) {
  // function to merge list of characters to one string
  return chars.join();
}

List<String>? splitStringToChar(String? inputValues) {
  // function to split the string to characters
  if (inputValues == null || inputValues.isEmpty) {
    return null;
  }

  return inputValues.split('');
}

String? accessSecondChar(String? items) {
  // function to access the second char from the string and return it
  if (items == null || items.length < 2) {
    return null;
  }

  return items[1];
}
