import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'update_order_copy_widget.dart' show UpdateOrderCopyWidget;
import 'package:flutter/material.dart';

class UpdateOrderCopyModel extends FlutterFlowModel<UpdateOrderCopyWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for Status widget.
  String? statusValue;
  FormFieldController<String>? statusValueController;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;
  // State field(s) for TransactionID widget.
  FocusNode? transactionIDFocusNode;
  TextEditingController? transactionIDTextController;
  String? Function(BuildContext, String?)? transactionIDTextControllerValidator;
  // State field(s) for OrderReturnorCancelReason widget.
  FocusNode? orderReturnorCancelReasonFocusNode;
  TextEditingController? orderReturnorCancelReasonTextController;
  String? Function(BuildContext, String?)?
      orderReturnorCancelReasonTextControllerValidator;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  TablesRecord? tableSelected;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    transactionIDFocusNode?.dispose();
    transactionIDTextController?.dispose();

    orderReturnorCancelReasonFocusNode?.dispose();
    orderReturnorCancelReasonTextController?.dispose();
  }

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
