import '/flutter_flow/flutter_flow_util.dart';
import 'no_pending_order_widget.dart' show NoPendingOrderWidget;
import 'package:flutter/material.dart';

class NoPendingOrderModel extends FlutterFlowModel<NoPendingOrderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
