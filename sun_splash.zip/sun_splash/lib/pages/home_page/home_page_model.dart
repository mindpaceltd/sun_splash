import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/pages/admin_side_bar/admin_side_bar_widget.dart';
import 'home_page_widget.dart' show HomePageWidget;
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  Local state fields for this page.

  DocumentReference? categoryName;

  List<DocumentReference> cartRefs = [];
  void addToCartRefs(DocumentReference item) => cartRefs.add(item);
  void removeFromCartRefs(DocumentReference item) => cartRefs.remove(item);
  void removeAtIndexFromCartRefs(int index) => cartRefs.removeAt(index);
  void insertAtIndexInCartRefs(int index, DocumentReference item) =>
      cartRefs.insert(index, item);
  void updateCartRefsAtIndex(int index, Function(DocumentReference) updateFn) =>
      cartRefs[index] = updateFn(cartRefs[index]);

  List<ItemsStruct> items = [];
  void addToItems(ItemsStruct item) => items.add(item);
  void removeFromItems(ItemsStruct item) => items.remove(item);
  void removeAtIndexFromItems(int index) => items.removeAt(index);
  void insertAtIndexInItems(int index, ItemsStruct item) =>
      items.insert(index, item);
  void updateItemsAtIndex(int index, Function(ItemsStruct) updateFn) =>
      items[index] = updateFn(items[index]);

  ///  State fields for stateful widgets in this page.

  // Model for AdminSideBar component.
  late AdminSideBarModel adminSideBarModel;
  // State field(s) for TextField widget.
  final textFieldKey = GlobalKey();
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? textFieldSelectedOption;
  String? Function(BuildContext, String?)? textControllerValidator;
  List<MenuItemsRecord> simpleSearchResults = [];
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  CartRecord? cartItem;
  // State field(s) for Carousel widget.
  CarouselSliderController? carouselController;
  int carouselCurrentIndex = 1;

  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;
  // State field(s) for Table widget.
  String? tableValue;
  FormFieldController<String>? tableValueController;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  OrdersRecord? createdOrder;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  TablesRecord? tableBooked;

  @override
  void initState(BuildContext context) {
    adminSideBarModel = createModel(context, () => AdminSideBarModel());
  }

  @override
  void dispose() {
    adminSideBarModel.dispose();
    textFieldFocusNode?.dispose();
  }

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
