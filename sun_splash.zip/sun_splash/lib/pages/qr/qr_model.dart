import '/flutter_flow/flutter_flow_util.dart';
import 'qr_widget.dart' show QrWidget;
import 'package:flutter/material.dart';

class QrModel extends FlutterFlowModel<QrWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
