import '/flutter_flow/flutter_flow_util.dart';
import '/pages/admin_side_bar/admin_side_bar_widget.dart';
import '/pages/top_nav/top_nav_widget.dart';
import 'admin_dashboard_widget.dart' show AdminDashboardWidget;
import 'package:flutter/material.dart';

class AdminDashboardModel extends FlutterFlowModel<AdminDashboardWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for AdminSideBar component.
  late AdminSideBarModel adminSideBarModel;
  // Model for TopNav component.
  late TopNavModel topNavModel;

  @override
  void initState(BuildContext context) {
    adminSideBarModel = createModel(context, () => AdminSideBarModel());
    topNavModel = createModel(context, () => TopNavModel());
  }

  @override
  void dispose() {
    adminSideBarModel.dispose();
    topNavModel.dispose();
  }
}
