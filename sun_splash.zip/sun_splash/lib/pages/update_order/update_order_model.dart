import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'update_order_widget.dart' show UpdateOrderWidget;
import 'package:flutter/material.dart';

class UpdateOrderModel extends FlutterFlowModel<UpdateOrderWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for Status widget.
  String? statusValue;
  FormFieldController<String>? statusValueController;
  // State field(s) for PaymentStatus widget.
  String? paymentStatusValue;
  FormFieldController<String>? paymentStatusValueController;
  // State field(s) for OrderReturnorCancelReason widget.
  FocusNode? orderReturnorCancelReasonFocusNode;
  TextEditingController? orderReturnorCancelReasonTextController;
  String? Function(BuildContext, String?)?
      orderReturnorCancelReasonTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    orderReturnorCancelReasonFocusNode?.dispose();
    orderReturnorCancelReasonTextController?.dispose();
  }
}
