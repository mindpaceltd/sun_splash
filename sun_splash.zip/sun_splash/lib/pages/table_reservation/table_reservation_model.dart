import '/flutter_flow/flutter_flow_util.dart';
import '/pages/admin_side_bar/admin_side_bar_widget.dart';
import 'table_reservation_widget.dart' show TableReservationWidget;
import 'package:flutter/material.dart';

class TableReservationModel extends FlutterFlowModel<TableReservationWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for AdminSideBar component.
  late AdminSideBarModel adminSideBarModel;
  // State field(s) for Name widget.
  FocusNode? nameFocusNode1;
  TextEditingController? nameTextController1;
  String? Function(BuildContext, String?)? nameTextController1Validator;
  // State field(s) for Name widget.
  FocusNode? nameFocusNode2;
  TextEditingController? nameTextController2;
  String? Function(BuildContext, String?)? nameTextController2Validator;

  @override
  void initState(BuildContext context) {
    adminSideBarModel = createModel(context, () => AdminSideBarModel());
  }

  @override
  void dispose() {
    adminSideBarModel.dispose();
    nameFocusNode1?.dispose();
    nameTextController1?.dispose();

    nameFocusNode2?.dispose();
    nameTextController2?.dispose();
  }
}
