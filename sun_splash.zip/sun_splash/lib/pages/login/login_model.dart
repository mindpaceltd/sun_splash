import '/flutter_flow/flutter_flow_util.dart';
import 'login_widget.dart' show LoginWidget;
import 'package:flutter/material.dart';

class LoginModel extends FlutterFlowModel<LoginWidget> {
  ///  Local state fields for this page.

  String? inputValues = '-';

  String? username;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Custom Action - addNumPadValues] action in Container widget.
  String? outtPut1;
  // Stores action output result for [Custom Action - addNumPadValues] action in Container widget.
  String? outtPu2;
  // Stores action output result for [Custom Action - addNumPadValues] action in Container widget.
  String? outtPut3;
  // Stores action output result for [Custom Action - addNumPadValues] action in Container widget.
  String? outtPut4;
  // Stores action output result for [Custom Action - addNumPadValues] action in Container widget.
  String? outtPut5;
  // Stores action output result for [Custom Action - addNumPadValues] action in Container widget.
  String? outtPut6;
  // Stores action output result for [Custom Action - addNumPadValues] action in Container widget.
  String? outtPut7;
  // Stores action output result for [Custom Action - addNumPadValues] action in Container widget.
  String? outtPut8;
  // Stores action output result for [Custom Action - addNumPadValues] action in Container widget.
  String? outtPut9;
  // Stores action output result for [Custom Action - addNumPadValues] action in Container widget.
  String? outtPut0;
  // Stores action output result for [Custom Action - deleteInputValue] action in Icon widget.
  String? remainingString;
  // Stores action output result for [Custom Action - mapEmails] action in Button widget.
  String? emailReturned;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
