import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_data_table.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/admin_side_bar/admin_side_bar_widget.dart';
import '/pages/top_nav/top_nav_widget.dart';
import 'product_category_widget.dart' show ProductCategoryWidget;
import 'package:flutter/material.dart';

class ProductCategoryModel extends FlutterFlowModel<ProductCategoryWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for AdminSideBar component.
  late AdminSideBarModel adminSideBarModel;
  // Model for TopNav component.
  late TopNavModel topNavModel;
  // State field(s) for PaginatedDataTable widget.
  final paginatedDataTableController =
      FlutterFlowDataTableController<CategoriesRecord>();

  @override
  void initState(BuildContext context) {
    adminSideBarModel = createModel(context, () => AdminSideBarModel());
    topNavModel = createModel(context, () => TopNavModel());
  }

  @override
  void dispose() {
    adminSideBarModel.dispose();
    topNavModel.dispose();
    paginatedDataTableController.dispose();
  }
}
