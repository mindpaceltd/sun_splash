import '/flutter_flow/flutter_flow_util.dart';
import 'order_details_widget.dart' show OrderDetailsWidget;
import 'package:flutter/material.dart';

class OrderDetailsModel extends FlutterFlowModel<OrderDetailsWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for OrderId widget.
  FocusNode? orderIdFocusNode;
  TextEditingController? orderIdTextController;
  String? Function(BuildContext, String?)? orderIdTextControllerValidator;
  // State field(s) for OrderAmount widget.
  FocusNode? orderAmountFocusNode;
  TextEditingController? orderAmountTextController;
  String? Function(BuildContext, String?)? orderAmountTextControllerValidator;
  // State field(s) for OrderStatus widget.
  FocusNode? orderStatusFocusNode;
  TextEditingController? orderStatusTextController;
  String? Function(BuildContext, String?)? orderStatusTextControllerValidator;
  // State field(s) for OrderType widget.
  FocusNode? orderTypeFocusNode;
  TextEditingController? orderTypeTextController;
  String? Function(BuildContext, String?)? orderTypeTextControllerValidator;
  // State field(s) for PaymentType widget.
  FocusNode? paymentTypeFocusNode;
  TextEditingController? paymentTypeTextController;
  String? Function(BuildContext, String?)? paymentTypeTextControllerValidator;
  // State field(s) for PaymentStatus widget.
  FocusNode? paymentStatusFocusNode;
  TextEditingController? paymentStatusTextController;
  String? Function(BuildContext, String?)? paymentStatusTextControllerValidator;
  // State field(s) for CustomerName widget.
  FocusNode? customerNameFocusNode;
  TextEditingController? customerNameTextController;
  String? Function(BuildContext, String?)? customerNameTextControllerValidator;
  // State field(s) for OrderReturnorCancelReason widget.
  FocusNode? orderReturnorCancelReasonFocusNode;
  TextEditingController? orderReturnorCancelReasonTextController;
  String? Function(BuildContext, String?)?
      orderReturnorCancelReasonTextControllerValidator;
  // State field(s) for OrderCreatedBy widget.
  FocusNode? orderCreatedByFocusNode;
  TextEditingController? orderCreatedByTextController;
  String? Function(BuildContext, String?)?
      orderCreatedByTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    orderIdFocusNode?.dispose();
    orderIdTextController?.dispose();

    orderAmountFocusNode?.dispose();
    orderAmountTextController?.dispose();

    orderStatusFocusNode?.dispose();
    orderStatusTextController?.dispose();

    orderTypeFocusNode?.dispose();
    orderTypeTextController?.dispose();

    paymentTypeFocusNode?.dispose();
    paymentTypeTextController?.dispose();

    paymentStatusFocusNode?.dispose();
    paymentStatusTextController?.dispose();

    customerNameFocusNode?.dispose();
    customerNameTextController?.dispose();

    orderReturnorCancelReasonFocusNode?.dispose();
    orderReturnorCancelReasonTextController?.dispose();

    orderCreatedByFocusNode?.dispose();
    orderCreatedByTextController?.dispose();
  }
}
