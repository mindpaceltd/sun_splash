import '/flutter_flow/flutter_flow_util.dart';
import 'print_receipt_widget.dart' show PrintReceiptWidget;
import 'package:flutter/material.dart';

class PrintReceiptModel extends FlutterFlowModel<PrintReceiptWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
