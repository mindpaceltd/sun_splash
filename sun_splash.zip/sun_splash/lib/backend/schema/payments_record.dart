import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PaymentsRecord extends FirestoreRecord {
  PaymentsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "order_id" field.
  DocumentReference? _orderId;
  DocumentReference? get orderId => _orderId;
  bool hasOrderId() => _orderId != null;

  // "payment_type" field.
  String? _paymentType;
  String get paymentType => _paymentType ?? '';
  bool hasPaymentType() => _paymentType != null;

  // "amount_paid" field.
  double? _amountPaid;
  double get amountPaid => _amountPaid ?? 0.0;
  bool hasAmountPaid() => _amountPaid != null;

  // "payment_date" field.
  DateTime? _paymentDate;
  DateTime? get paymentDate => _paymentDate;
  bool hasPaymentDate() => _paymentDate != null;

  // "transactionID" field.
  String? _transactionID;
  String get transactionID => _transactionID ?? '';
  bool hasTransactionID() => _transactionID != null;

  // "paymentID" field.
  DocumentReference? _paymentID;
  DocumentReference? get paymentID => _paymentID;
  bool hasPaymentID() => _paymentID != null;

  void _initializeFields() {
    _orderId = snapshotData['order_id'] as DocumentReference?;
    _paymentType = snapshotData['payment_type'] as String?;
    _amountPaid = castToType<double>(snapshotData['amount_paid']);
    _paymentDate = snapshotData['payment_date'] as DateTime?;
    _transactionID = snapshotData['transactionID'] as String?;
    _paymentID = snapshotData['paymentID'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Payments');

  static Stream<PaymentsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PaymentsRecord.fromSnapshot(s));

  static Future<PaymentsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PaymentsRecord.fromSnapshot(s));

  static PaymentsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PaymentsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PaymentsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PaymentsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PaymentsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PaymentsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPaymentsRecordData({
  DocumentReference? orderId,
  String? paymentType,
  double? amountPaid,
  DateTime? paymentDate,
  String? transactionID,
  DocumentReference? paymentID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'order_id': orderId,
      'payment_type': paymentType,
      'amount_paid': amountPaid,
      'payment_date': paymentDate,
      'transactionID': transactionID,
      'paymentID': paymentID,
    }.withoutNulls,
  );

  return firestoreData;
}

class PaymentsRecordDocumentEquality implements Equality<PaymentsRecord> {
  const PaymentsRecordDocumentEquality();

  @override
  bool equals(PaymentsRecord? e1, PaymentsRecord? e2) {
    return e1?.orderId == e2?.orderId &&
        e1?.paymentType == e2?.paymentType &&
        e1?.amountPaid == e2?.amountPaid &&
        e1?.paymentDate == e2?.paymentDate &&
        e1?.transactionID == e2?.transactionID &&
        e1?.paymentID == e2?.paymentID;
  }

  @override
  int hash(PaymentsRecord? e) => const ListEquality().hash([
        e?.orderId,
        e?.paymentType,
        e?.amountPaid,
        e?.paymentDate,
        e?.transactionID,
        e?.paymentID
      ]);

  @override
  bool isValidKey(Object? o) => o is PaymentsRecord;
}
