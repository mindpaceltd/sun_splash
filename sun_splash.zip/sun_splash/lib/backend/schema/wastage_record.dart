import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class WastageRecord extends FirestoreRecord {
  WastageRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "itemRef" field.
  DocumentReference? _itemRef;
  DocumentReference? get itemRef => _itemRef;
  bool hasItemRef() => _itemRef != null;

  // "created_date" field.
  DateTime? _createdDate;
  DateTime? get createdDate => _createdDate;
  bool hasCreatedDate() => _createdDate != null;

  // "Qty" field.
  int? _qty;
  int get qty => _qty ?? 0;
  bool hasQty() => _qty != null;

  // "userRef" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "reason" field.
  String? _reason;
  String get reason => _reason ?? '';
  bool hasReason() => _reason != null;

  void _initializeFields() {
    _itemRef = snapshotData['itemRef'] as DocumentReference?;
    _createdDate = snapshotData['created_date'] as DateTime?;
    _qty = castToType<int>(snapshotData['Qty']);
    _userRef = snapshotData['userRef'] as DocumentReference?;
    _reason = snapshotData['reason'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Wastage');

  static Stream<WastageRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => WastageRecord.fromSnapshot(s));

  static Future<WastageRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => WastageRecord.fromSnapshot(s));

  static WastageRecord fromSnapshot(DocumentSnapshot snapshot) =>
      WastageRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static WastageRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      WastageRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'WastageRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is WastageRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createWastageRecordData({
  DocumentReference? itemRef,
  DateTime? createdDate,
  int? qty,
  DocumentReference? userRef,
  String? reason,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'itemRef': itemRef,
      'created_date': createdDate,
      'Qty': qty,
      'userRef': userRef,
      'reason': reason,
    }.withoutNulls,
  );

  return firestoreData;
}

class WastageRecordDocumentEquality implements Equality<WastageRecord> {
  const WastageRecordDocumentEquality();

  @override
  bool equals(WastageRecord? e1, WastageRecord? e2) {
    return e1?.itemRef == e2?.itemRef &&
        e1?.createdDate == e2?.createdDate &&
        e1?.qty == e2?.qty &&
        e1?.userRef == e2?.userRef &&
        e1?.reason == e2?.reason;
  }

  @override
  int hash(WastageRecord? e) => const ListEquality()
      .hash([e?.itemRef, e?.createdDate, e?.qty, e?.userRef, e?.reason]);

  @override
  bool isValidKey(Object? o) => o is WastageRecord;
}
