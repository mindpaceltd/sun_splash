import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReservationsRecord extends FirestoreRecord {
  ReservationsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "customer_id" field.
  DocumentReference? _customerId;
  DocumentReference? get customerId => _customerId;
  bool hasCustomerId() => _customerId != null;

  // "table_id" field.
  DocumentReference? _tableId;
  DocumentReference? get tableId => _tableId;
  bool hasTableId() => _tableId != null;

  // "reservation_date" field.
  DateTime? _reservationDate;
  DateTime? get reservationDate => _reservationDate;
  bool hasReservationDate() => _reservationDate != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  void _initializeFields() {
    _customerId = snapshotData['customer_id'] as DocumentReference?;
    _tableId = snapshotData['table_id'] as DocumentReference?;
    _reservationDate = snapshotData['reservation_date'] as DateTime?;
    _status = snapshotData['status'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Reservations');

  static Stream<ReservationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReservationsRecord.fromSnapshot(s));

  static Future<ReservationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReservationsRecord.fromSnapshot(s));

  static ReservationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReservationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReservationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReservationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReservationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReservationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReservationsRecordData({
  DocumentReference? customerId,
  DocumentReference? tableId,
  DateTime? reservationDate,
  String? status,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'customer_id': customerId,
      'table_id': tableId,
      'reservation_date': reservationDate,
      'status': status,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReservationsRecordDocumentEquality
    implements Equality<ReservationsRecord> {
  const ReservationsRecordDocumentEquality();

  @override
  bool equals(ReservationsRecord? e1, ReservationsRecord? e2) {
    return e1?.customerId == e2?.customerId &&
        e1?.tableId == e2?.tableId &&
        e1?.reservationDate == e2?.reservationDate &&
        e1?.status == e2?.status;
  }

  @override
  int hash(ReservationsRecord? e) => const ListEquality()
      .hash([e?.customerId, e?.tableId, e?.reservationDate, e?.status]);

  @override
  bool isValidKey(Object? o) => o is ReservationsRecord;
}
