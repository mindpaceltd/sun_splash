import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OrdersRecord extends FirestoreRecord {
  OrdersRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "user_id" field.
  DocumentReference? _userId;
  DocumentReference? get userId => _userId;
  bool hasUserId() => _userId != null;

  // "customer_id" field.
  DocumentReference? _customerId;
  DocumentReference? get customerId => _customerId;
  bool hasCustomerId() => _customerId != null;

  // "order_date" field.
  DateTime? _orderDate;
  DateTime? get orderDate => _orderDate;
  bool hasOrderDate() => _orderDate != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "total_amount" field.
  double? _totalAmount;
  double get totalAmount => _totalAmount ?? 0.0;
  bool hasTotalAmount() => _totalAmount != null;

  // "OrderType" field.
  String? _orderType;
  String get orderType => _orderType ?? '';
  bool hasOrderType() => _orderType != null;

  // "Payment_Type" field.
  String? _paymentType;
  String get paymentType => _paymentType ?? '';
  bool hasPaymentType() => _paymentType != null;

  // "Payment_Status" field.
  String? _paymentStatus;
  String get paymentStatus => _paymentStatus ?? '';
  bool hasPaymentStatus() => _paymentStatus != null;

  // "Reason" field.
  String? _reason;
  String get reason => _reason ?? '';
  bool hasReason() => _reason != null;

  // "table" field.
  String? _table;
  String get table => _table ?? '';
  bool hasTable() => _table != null;

  // "items" field.
  List<ItemsStruct>? _items;
  List<ItemsStruct> get items => _items ?? const [];
  bool hasItems() => _items != null;

  void _initializeFields() {
    _userId = snapshotData['user_id'] as DocumentReference?;
    _customerId = snapshotData['customer_id'] as DocumentReference?;
    _orderDate = snapshotData['order_date'] as DateTime?;
    _status = snapshotData['status'] as String?;
    _totalAmount = castToType<double>(snapshotData['total_amount']);
    _orderType = snapshotData['OrderType'] as String?;
    _paymentType = snapshotData['Payment_Type'] as String?;
    _paymentStatus = snapshotData['Payment_Status'] as String?;
    _reason = snapshotData['Reason'] as String?;
    _table = snapshotData['table'] as String?;
    _items = getStructList(
      snapshotData['items'],
      ItemsStruct.fromMap,
    );
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Orders');

  static Stream<OrdersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OrdersRecord.fromSnapshot(s));

  static Future<OrdersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => OrdersRecord.fromSnapshot(s));

  static OrdersRecord fromSnapshot(DocumentSnapshot snapshot) => OrdersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OrdersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OrdersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OrdersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OrdersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOrdersRecordData({
  DocumentReference? userId,
  DocumentReference? customerId,
  DateTime? orderDate,
  String? status,
  double? totalAmount,
  String? orderType,
  String? paymentType,
  String? paymentStatus,
  String? reason,
  String? table,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user_id': userId,
      'customer_id': customerId,
      'order_date': orderDate,
      'status': status,
      'total_amount': totalAmount,
      'OrderType': orderType,
      'Payment_Type': paymentType,
      'Payment_Status': paymentStatus,
      'Reason': reason,
      'table': table,
    }.withoutNulls,
  );

  return firestoreData;
}

class OrdersRecordDocumentEquality implements Equality<OrdersRecord> {
  const OrdersRecordDocumentEquality();

  @override
  bool equals(OrdersRecord? e1, OrdersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.userId == e2?.userId &&
        e1?.customerId == e2?.customerId &&
        e1?.orderDate == e2?.orderDate &&
        e1?.status == e2?.status &&
        e1?.totalAmount == e2?.totalAmount &&
        e1?.orderType == e2?.orderType &&
        e1?.paymentType == e2?.paymentType &&
        e1?.paymentStatus == e2?.paymentStatus &&
        e1?.reason == e2?.reason &&
        e1?.table == e2?.table &&
        listEquality.equals(e1?.items, e2?.items);
  }

  @override
  int hash(OrdersRecord? e) => const ListEquality().hash([
        e?.userId,
        e?.customerId,
        e?.orderDate,
        e?.status,
        e?.totalAmount,
        e?.orderType,
        e?.paymentType,
        e?.paymentStatus,
        e?.reason,
        e?.table,
        e?.items
      ]);

  @override
  bool isValidKey(Object? o) => o is OrdersRecord;
}
