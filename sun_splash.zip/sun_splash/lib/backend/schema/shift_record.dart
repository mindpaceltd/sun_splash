import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ShiftRecord extends FirestoreRecord {
  ShiftRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "CashierID" field.
  DocumentReference? _cashierID;
  DocumentReference? get cashierID => _cashierID;
  bool hasCashierID() => _cashierID != null;

  // "Role" field.
  String? _role;
  String get role => _role ?? '';
  bool hasRole() => _role != null;

  // "StartTime" field.
  DateTime? _startTime;
  DateTime? get startTime => _startTime;
  bool hasStartTime() => _startTime != null;

  // "EndTime" field.
  DateTime? _endTime;
  DateTime? get endTime => _endTime;
  bool hasEndTime() => _endTime != null;

  // "ShiftStatus" field.
  String? _shiftStatus;
  String get shiftStatus => _shiftStatus ?? '';
  bool hasShiftStatus() => _shiftStatus != null;

  // "duration" field.
  int? _duration;
  int get duration => _duration ?? 0;
  bool hasDuration() => _duration != null;

  // "itemSoldList" field.
  List<ItemsStruct>? _itemSoldList;
  List<ItemsStruct> get itemSoldList => _itemSoldList ?? const [];
  bool hasItemSoldList() => _itemSoldList != null;

  void _initializeFields() {
    _cashierID = snapshotData['CashierID'] as DocumentReference?;
    _role = snapshotData['Role'] as String?;
    _startTime = snapshotData['StartTime'] as DateTime?;
    _endTime = snapshotData['EndTime'] as DateTime?;
    _shiftStatus = snapshotData['ShiftStatus'] as String?;
    _duration = castToType<int>(snapshotData['duration']);
    _itemSoldList = getStructList(
      snapshotData['itemSoldList'],
      ItemsStruct.fromMap,
    );
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Shift');

  static Stream<ShiftRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ShiftRecord.fromSnapshot(s));

  static Future<ShiftRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ShiftRecord.fromSnapshot(s));

  static ShiftRecord fromSnapshot(DocumentSnapshot snapshot) => ShiftRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ShiftRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ShiftRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ShiftRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ShiftRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createShiftRecordData({
  DocumentReference? cashierID,
  String? role,
  DateTime? startTime,
  DateTime? endTime,
  String? shiftStatus,
  int? duration,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'CashierID': cashierID,
      'Role': role,
      'StartTime': startTime,
      'EndTime': endTime,
      'ShiftStatus': shiftStatus,
      'duration': duration,
    }.withoutNulls,
  );

  return firestoreData;
}

class ShiftRecordDocumentEquality implements Equality<ShiftRecord> {
  const ShiftRecordDocumentEquality();

  @override
  bool equals(ShiftRecord? e1, ShiftRecord? e2) {
    const listEquality = ListEquality();
    return e1?.cashierID == e2?.cashierID &&
        e1?.role == e2?.role &&
        e1?.startTime == e2?.startTime &&
        e1?.endTime == e2?.endTime &&
        e1?.shiftStatus == e2?.shiftStatus &&
        e1?.duration == e2?.duration &&
        listEquality.equals(e1?.itemSoldList, e2?.itemSoldList);
  }

  @override
  int hash(ShiftRecord? e) => const ListEquality().hash([
        e?.cashierID,
        e?.role,
        e?.startTime,
        e?.endTime,
        e?.shiftStatus,
        e?.duration,
        e?.itemSoldList
      ]);

  @override
  bool isValidKey(Object? o) => o is ShiftRecord;
}
