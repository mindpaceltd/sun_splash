import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TablesRecord extends FirestoreRecord {
  TablesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "table_name" field.
  String? _tableName;
  String get tableName => _tableName ?? '';
  bool hasTableName() => _tableName != null;

  // "Status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "tableNumber" field.
  int? _tableNumber;
  int get tableNumber => _tableNumber ?? 0;
  bool hasTableNumber() => _tableNumber != null;

  void _initializeFields() {
    _tableName = snapshotData['table_name'] as String?;
    _status = snapshotData['Status'] as String?;
    _tableNumber = castToType<int>(snapshotData['tableNumber']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Tables');

  static Stream<TablesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TablesRecord.fromSnapshot(s));

  static Future<TablesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TablesRecord.fromSnapshot(s));

  static TablesRecord fromSnapshot(DocumentSnapshot snapshot) => TablesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TablesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TablesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TablesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TablesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTablesRecordData({
  String? tableName,
  String? status,
  int? tableNumber,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'table_name': tableName,
      'Status': status,
      'tableNumber': tableNumber,
    }.withoutNulls,
  );

  return firestoreData;
}

class TablesRecordDocumentEquality implements Equality<TablesRecord> {
  const TablesRecordDocumentEquality();

  @override
  bool equals(TablesRecord? e1, TablesRecord? e2) {
    return e1?.tableName == e2?.tableName &&
        e1?.status == e2?.status &&
        e1?.tableNumber == e2?.tableNumber;
  }

  @override
  int hash(TablesRecord? e) =>
      const ListEquality().hash([e?.tableName, e?.status, e?.tableNumber]);

  @override
  bool isValidKey(Object? o) => o is TablesRecord;
}
