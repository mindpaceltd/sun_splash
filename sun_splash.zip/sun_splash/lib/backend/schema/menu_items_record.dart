import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MenuItemsRecord extends FirestoreRecord {
  MenuItemsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "item_name" field.
  String? _itemName;
  String get itemName => _itemName ?? '';
  bool hasItemName() => _itemName != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "price" field.
  double? _price;
  double get price => _price ?? 0.0;
  bool hasPrice() => _price != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "category_id" field.
  DocumentReference? _categoryId;
  DocumentReference? get categoryId => _categoryId;
  bool hasCategoryId() => _categoryId != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  bool hasId() => _id != null;

  // "itemsReceived" field.
  int? _itemsReceived;
  int get itemsReceived => _itemsReceived ?? 0;
  bool hasItemsReceived() => _itemsReceived != null;

  // "itemsSold" field.
  int? _itemsSold;
  int get itemsSold => _itemsSold ?? 0;
  bool hasItemsSold() => _itemsSold != null;

  // "reason" field.
  String? _reason;
  String get reason => _reason ?? '';
  bool hasReason() => _reason != null;

  // "Qty" field.
  int? _qty;
  int get qty => _qty ?? 0;
  bool hasQty() => _qty != null;

  void _initializeFields() {
    _itemName = snapshotData['item_name'] as String?;
    _description = snapshotData['description'] as String?;
    _price = castToType<double>(snapshotData['price']);
    _photoUrl = snapshotData['photo_url'] as String?;
    _categoryId = snapshotData['category_id'] as DocumentReference?;
    _status = snapshotData['status'] as String?;
    _id = snapshotData['id'] as String?;
    _itemsReceived = castToType<int>(snapshotData['itemsReceived']);
    _itemsSold = castToType<int>(snapshotData['itemsSold']);
    _reason = snapshotData['reason'] as String?;
    _qty = castToType<int>(snapshotData['Qty']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Menu_Items');

  static Stream<MenuItemsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MenuItemsRecord.fromSnapshot(s));

  static Future<MenuItemsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MenuItemsRecord.fromSnapshot(s));

  static MenuItemsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MenuItemsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MenuItemsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MenuItemsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MenuItemsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MenuItemsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMenuItemsRecordData({
  String? itemName,
  String? description,
  double? price,
  String? photoUrl,
  DocumentReference? categoryId,
  String? status,
  String? id,
  int? itemsReceived,
  int? itemsSold,
  String? reason,
  int? qty,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'item_name': itemName,
      'description': description,
      'price': price,
      'photo_url': photoUrl,
      'category_id': categoryId,
      'status': status,
      'id': id,
      'itemsReceived': itemsReceived,
      'itemsSold': itemsSold,
      'reason': reason,
      'Qty': qty,
    }.withoutNulls,
  );

  return firestoreData;
}

class MenuItemsRecordDocumentEquality implements Equality<MenuItemsRecord> {
  const MenuItemsRecordDocumentEquality();

  @override
  bool equals(MenuItemsRecord? e1, MenuItemsRecord? e2) {
    return e1?.itemName == e2?.itemName &&
        e1?.description == e2?.description &&
        e1?.price == e2?.price &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.categoryId == e2?.categoryId &&
        e1?.status == e2?.status &&
        e1?.id == e2?.id &&
        e1?.itemsReceived == e2?.itemsReceived &&
        e1?.itemsSold == e2?.itemsSold &&
        e1?.reason == e2?.reason &&
        e1?.qty == e2?.qty;
  }

  @override
  int hash(MenuItemsRecord? e) => const ListEquality().hash([
        e?.itemName,
        e?.description,
        e?.price,
        e?.photoUrl,
        e?.categoryId,
        e?.status,
        e?.id,
        e?.itemsReceived,
        e?.itemsSold,
        e?.reason,
        e?.qty
      ]);

  @override
  bool isValidKey(Object? o) => o is MenuItemsRecord;
}
