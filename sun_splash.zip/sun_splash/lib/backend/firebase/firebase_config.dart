import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyAWRZ2BSrsBAl4fyBLqJr4k9_b-_oSkyU0",
            authDomain: "bamboo-e0uslo.firebaseapp.com",
            projectId: "bamboo-e0uslo",
            storageBucket: "bamboo-e0uslo.appspot.com",
            messagingSenderId: "1077577176385",
            appId: "1:1077577176385:web:45168a3933c708abf13dc0"));
  } else {
    await Firebase.initializeApp();
  }
}
