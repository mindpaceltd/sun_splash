import 'package:flutter/material.dart';
import 'flutter_flow/request_manager.dart';
import '/backend/backend.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _isShiftActive = prefs.getBool('ff_isShiftActive') ?? _isShiftActive;
    });
    _safeInit(() {
      _elapsedTime = prefs.getInt('ff_elapsedTime') ?? _elapsedTime;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  double _cartTotal = 0.0;
  double get cartTotal => _cartTotal;
  set cartTotal(double value) {
    _cartTotal = value;
  }

  String _Payment = '';
  String get Payment => _Payment;
  set Payment(String value) {
    _Payment = value;
  }

  String _pinNum = '';
  String get pinNum => _pinNum;
  set pinNum(String value) {
    _pinNum = value;
  }

  bool _isShiftActive = false;
  bool get isShiftActive => _isShiftActive;
  set isShiftActive(bool value) {
    _isShiftActive = value;
    prefs.setBool('ff_isShiftActive', value);
  }

  int _elapsedTime = 0;
  int get elapsedTime => _elapsedTime;
  set elapsedTime(int value) {
    _elapsedTime = value;
    prefs.setInt('ff_elapsedTime', value);
  }

  final _categoryManager = StreamRequestManager<List<CategoriesRecord>>();
  Stream<List<CategoriesRecord>> category({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Stream<List<CategoriesRecord>> Function() requestFn,
  }) =>
      _categoryManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCategoryCache() => _categoryManager.clear();
  void clearCategoryCacheKey(String? uniqueKey) =>
      _categoryManager.clearRequest(uniqueKey);
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
