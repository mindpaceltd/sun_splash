import '/flutter_flow/flutter_flow_util.dart';
import '/pages/admin_side_bar/admin_side_bar_widget.dart';
import 'auth2_profile_widget.dart' show Auth2ProfileWidget;
import 'package:flutter/material.dart';

class Auth2ProfileModel extends FlutterFlowModel<Auth2ProfileWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for AdminSideBar component.
  late AdminSideBarModel adminSideBarModel;

  @override
  void initState(BuildContext context) {
    adminSideBarModel = createModel(context, () => AdminSideBarModel());
  }

  @override
  void dispose() {
    adminSideBarModel.dispose();
  }
}
